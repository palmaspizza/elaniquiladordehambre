# El Aniquilador de Hambre · Notas del proyecto (v2)

## Archivos
index.html (tienda + bot) · admin.html (panel con login) · reglas-firebase.json · _headers · carpeta img/ y burgerprincipal.jpg (no incluidas en el zip).

## Firebase (REST, sin SDK) · proyecto elaniquiladordehambre-5d19c · raíz /aniquilador
databaseURL ASUMIDA: https://elaniquiladordehambre-5d19c-default-rtdb.firebaseio.com (verificar; si la base está en otra región la URL cambia).
aniquilador
├─ meta   { seeded:true }
├─ config { despacho, pagos, promo_texto, promo_titulo, promo_activa, promo_producto, promo_img, promo_v,
│           sucursales { nunoa|renca : { whatsapp, horarios { dom|lun|mar|mie|jue|vie|sab : { abierto, desde, hasta } } } } }
├─ menu   └─ <id> { orden, cat, nombre, precio, desc, disponible, opts[], badge, combo, recomendada, veg, img_url, foto_v }
└─ fotos  └─ <id> "data:image/jpeg;base64,…" (solo se baja si cambia foto_v) · _promo = banner (versión en config/promo_v)
Compatibilidad: config.horarios y config.whatsapp antiguos ya no se usan; si faltan datos, ambos archivos usan los horarios de respaldo (Ñuñoa lun–sáb 12:30–22:00, dom cerrado; Renca lun–sáb 12:00–22:30, dom 17:00–22:00).

## Seguridad
- Lectura pública solo de /aniquilador; escritura solo con login y UID del dueño (reglas). Registro de usuarios desactivado.
- Panel: Firebase Auth por REST (identitytoolkit / securetoken). Token en memoria; el refresh token queda en sessionStorage o, si marcas "Recordarme", en localStorage. Botón "Salir".
- Todo texto que viene de Firebase se escapa antes de pintarse en la tienda.
- El chat NO guarda mensajes en ningún lado (corre en el navegador). La ubicación para "sucursal más cercana" se usa en el momento y no se guarda.
- _headers: CSP, anti-iframe, nosniff, noindex en admin. (script-src lleva 'unsafe-inline' porque el código es inline.)

## Sucursales, horarios y bot
SUCURSALES (index): id, lat/lng APROXIMADOS (solo para "más cercana"; verificar), dirección y WhatsApp (el panel puede sobrescribir el WhatsApp).
Último pedido = cierre − 15 min (bot, estado en el carrito). Bot: un botón dinámico de horario (cierran/abren), asesor con elección de sucursal o la más cercana.

## Banner "Promo del día"
Editable en Panel > Configuración: activar, título, texto, producto del botón, imagen (Cloudinary o Firebase). Se muestra al inicio de la tienda.

## Pendiente
Confirmar databaseURL, UID en reglas, coordenadas de sucursales, datos de Cloudinary.
