# Instalación (v2)
1. Sube index.html, admin.html y _headers junto a tu carpeta img/ (y burgerprincipal.jpg). _headers aplica cabeceras de seguridad en Cloudflare Pages/Netlify.
2. Firebase (proyecto elaniquiladordehambre-5d19c):
   - Realtime Database > crear base. Copia su URL; si NO es https://elaniquiladordehambre-5d19c-default-rtdb.firebaseio.com cámbiala en index.html y admin.html (constante FIREBASE.databaseURL).
   - Authentication > Método de acceso > activa Correo/Contraseña. En Configuración > Acciones del usuario desactiva "Permitir registro". Crea UN usuario (el dueño) y copia su UID.
   - Realtime Database > Reglas: pega reglas-firebase.json y reemplaza PEGA_AQUI_EL_UID_DEL_DUENO por ese UID. Publicar.
3. Abre admin.html, entra con ese correo y contraseña (la contraseña vive solo en Firebase). Se siembra el menú y los horarios.
4. Cloudinary (opcional): completa CLOUD={cloud,preset} en admin.html (preset "unsigned" con límite de formato y tamaño).
Más detalle en NOTAS-PROYECTO.md.
